import React from 'react';
import { useFormik } from 'formik';
import * as Yup from 'yup';

const BookingForm = () => {
  const formik = useFormik({
    initialValues: {
      date: '',
      time: '',
      guests: '',
      occasion: '',
    },
    validationSchema: Yup.object({
      date: Yup.string().required('Required'),
      time: Yup.string().required('Required'),
      guests: Yup.number().min(1).max(10).required('Required'),
      occasion: Yup.string().required('Required'),
    }),
    onSubmit: values => {
      alert(JSON.stringify(values, null, 2));
    },
  });

  return (
    <form onSubmit={formik.handleSubmit}>
      <label>Date:</label>
      <input type="date" name="date" onChange={formik.handleChange} value={formik.values.date} />
      {formik.errors.date && <div>{formik.errors.date}</div>}

      <label>Time:</label>
      <input type="time" name="time" onChange={formik.handleChange} value={formik.values.time} />
      {formik.errors.time && <div>{formik.errors.time}</div>}

      <label>Number of guests:</label>
      <input type="number" name="guests" onChange={formik.handleChange} value={formik.values.guests} />
      {formik.errors.guests && <div>{formik.errors.guests}</div>}

      <label>Occasion:</label>
      <select name="occasion" onChange={formik.handleChange} value={formik.values.occasion}>
        <option value="">Select</option>
        <option value="Birthday">Birthday</option>
        <option value="Anniversary">Anniversary</option>
      </select>
      {formik.errors.occasion && <div>{formik.errors.occasion}</div>}

      <button type="submit">Book Table</button>
    </form>
  );
};

export default BookingForm;