# Little Lemon Booking Form

A simple table reservation form for the Little Lemon website.

## Features
- React form with Formik & Yup validation
- Clean and responsive layout

## Run locally
```bash
npm install
npm run dev
```